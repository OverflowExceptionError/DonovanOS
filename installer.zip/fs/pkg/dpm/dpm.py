import requests,sys
from zipfile import ZipFile
# with ZipFile('/pkg/dpm/example.dpm') as mydpm:
#     mydpm.extractall('/')
doit = True
try:
    b = open(sys.argv[1] + '.ppm', 'rb').read()
except:
    pass
else:
    doit = False
if doit:
    b = requests.get("https://github.com/OverflowExceptionError/Website/raw/main/" + sys.argv[1] + ".ppm", stream=True)
    handle = open('/pkg/dpm/' + sys.argv[1] + '.dpm', "wb")
    for chunk in b.iter_content(chunk_size=512):
        if chunk:  # filter out keep-alive new chunks
            handle.write(chunk)
    handle.close()
else:
    handle = open('/pkg/dpm/' + sys.argv[1] + '.dpm', "wb")
    handle.write(b)
    handle.close()
with ZipFile('/pkg/dpm/' + sys.argv[1] +'.dpm') as mydpm:
    if sys.argv[len(sys.argv) - 1] == 'root':
        mydpm.extractall(sys.argv[len(sys.argv) - 2] + '/')
    else:
        mydpm.extractall(sys.argv[len(sys.argv) - 2] + '/pkg/' + sys.argv[1])
print('Package \'' + sys.argv[1] + '\' has been successfully installed.')