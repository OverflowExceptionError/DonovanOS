# DonovanOS Installer
# (C) 2022 DonovanOS Development
# This application, despite abiding by the DPM Package/Shell Rules, can NOT be installed properly.
def shell_entry(user,version):
    print('Checking for compatible devices...')
    print('Found Python UNKNOWN VERSION')
    print('Welcome to the DonovanOS Installer')
    print('Options:')
    print('1. Install')
    print('2. Quit')
    a = input('Choose > ')
    if a == '1':
        pass
    else:
        exit()
    print('Setting up drives for usage...')
    print('Looking for local drive C:/')
    import os
    os.chdir('/pkg/installer')
    print('Would you like to install to a diffrent location? (Default: C:/donovanosldr)')
    a = input('Choose (Y/N) > ')
    if a == 'Y' or a == 'yes':
        il = input('Please type your install location > ')
    else:
        il = 'C:/donovanosldr'
    os.mkdir(il)
    os.mkdir(il + '/fs')
    print('Options for type of DonovanOS you want to install')
    print('1. Full Enviroment')
    print('2. Mini Enviroment')
    a = input('Choose > ')
    if a == '1':
        a = 'full'
    if a == '2':
        a = 'mini'
    os.system('py /pkg/dpm/dpm.py ' + a + ' ' + il + ' root')
    print('Successfully installed DonovanOS!')