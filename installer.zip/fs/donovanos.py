nots = True
import time, os
devname = 'device-donovanos'
drivename = 'Z'
os.system('subst ' + drivename + ': .')
os.chdir(drivename + ':/')
while nots:
    print('Checking for components folder... [ WORKING ]')
    time.sleep(2)
    os.system('cls')
    try:
        os.chdir('components')
    except:
        print('Checking for components folder... [ FAILED ]')
        print('KERNEL PANIC')
        print('Internal-panic0a')
        print('Componenets folder does not exist. Please reinstall DonovanOS')
        exit()
    else:
        print('Checking for components folder... [ SUCCESS ]')
        os.chdir('..')
        nots = False
print('Setting device name to ' + devname)
devname = devname
ver = '0.1a'
print('Welcome to DonovanOS ' + ver)
user = 'login'
def login_prompt(user):
    print('Login: ')
    try:
        ld = open('logindata.txt').read()
    except:
        print(os.listdir())
        ld = 'root,'
    ld = ld.split('\n')
    logd = []
    numeral = 1
    for e in ld:
        logd.append([e.split(',')[0],e.split(',')[1]])
    for e in logd:
        print(str(numeral) + '. ' + e[0])
        numeral += 1
    numeral = 1
    a = int(input('Choose: '))
    for e in range(1,len(logd) + 1):
        if a == e:
            b = input('Password: ')
            if b == logd[e - 1][1]:
                user = logd[e - 1][0]
                return user
            else:
                login_prompt(user)
    return 'login'
def shell_prompt(user,ver):
    numeral = 1
    try:
        sd = open('shells.txt').read()
    except:
        print(os.listdir())
        sd = 'DonovanOS Not Advanced SHell,components.dterm'
    sd = sd.split('\n')
    shdata = []
    for e in sd:
        shdata.append([e.split(',')[0],e.split(',')[1]])
    print('Shell:')
    for e in shdata:
        print(str(numeral) + '. ' + e[0])
        numeral += 1
    numeral = 1
    a = int(input('Choose: '))
    for e in range(0,len(shdata)):
        if a == e + 1:
            from importlib import import_module
            MainClass = import_module(shdata[e][1])
            MainClass.shell_entry(user,ver)
user = login_prompt(user)
shell_prompt(user,ver)
os.chdir('C:/')
os.system('subst ' + drivename + ': /d')