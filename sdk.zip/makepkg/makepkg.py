import shutil,sys,os
def make():
    try:
        shutil.make_archive(sys.argv[2], 'zip', sys.argv[1])
        name = sys.argv[2]
    except:
        try:
            shutil.make_archive(sys.argv[1], 'zip', sys.argv[1])
            name = sys.argv[1]
        except:
            shutil.make_archive('package','zip','package')
            name = 'package'
    a = open(name + '.ppm','wb')
    b = open(name + '.zip','rb')
    a.write(b.read())
    b.close()
    a.close()
    os.remove(name + '.zip')
if __name__ == '__main__':
    make()