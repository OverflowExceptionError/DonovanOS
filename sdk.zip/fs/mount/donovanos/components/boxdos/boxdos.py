import pygame
import components.boxdos.spritesheet as ss
window = pygame.display.set_mode((640,480))
try:
    font = ss.spritesheet("/pkg/boxdos/boxdos-font-addon/font.png")
except:
    print("No font in addon - loading core default")
    font = ss.spritesheet("/pkg/boxdos/boxdos-core/font.png")
try:
    gfont = ss.spritesheet("/pkg/boxdos/boxdos-font-addon/grfxfont.png")
except:
    print("No graphics font in addon - loading core default")
    gfont = ss.spritesheet("/pkg/boxdos/boxdos-core/grfxfont.png")
lowerA = font.image_at([0,0,6,9])
upperB = font.image_at([6,0,6,9])
lowerC = font.image_at([12,0,6,9])
upperD = font.image_at([18,0,6,9])
lowerE = font.image_at([6*4,0,6,9])
upperF = font.image_at([6*5,0,6,9])
lowerG = font.image_at([6*6,0,6,9])
upperH = font.image_at([6*7,0,6,9])
lowerI = font.image_at([6*8,0,6,9])
upperJ = font.image_at([6*9,0,6,9])
upperK = font.image_at([6*10,0,6,9])
upperL = font.image_at([6*11,0,6,9])
upperM = font.image_at([6*12,0,6,9])
upperN = font.image_at([6*13,0,6,9])
upperO = font.image_at([6*14,0,6,9])
upperP = font.image_at([6*15,0,6,9])
upperQ = font.image_at([6*16,0,6,9])
upperR = font.image_at([6*17,0,6,9])
glowerA = gfont.image_at([0,0,6,9])
gupperA = gfont.image_at([6,0,6,9])
glowerB = gfont.image_at([12,0,6,9])
gupperB = gfont.image_at([18,0,6,9])
glowerC = gfont.image_at([6*4,0,6,9])
gupperC = gfont.image_at([6*5,0,6,9])
glowerD = gfont.image_at([6*6,0,6,9])
gupperD = gfont.image_at([6*7,0,6,9])
glowerE = gfont.image_at([6*8,0,6,9])
gupperE = gfont.image_at([6*9,0,6,9])
gColorPacmanO = gfont.image_at([6*10,0,6,9])
gColorPacmanCL = gfont.image_at([6*11,0,6,9])
gNothing = gfont.image_at([6*12,0,6,9])
gFlipPipeNC = gfont.image_at([6*13,0,6,9])
gFlipPipeC = gfont.image_at([6*14,0,6,9])
fontTest = False
lowerOnly = False
graphic = False
characters = [lowerA,upperB,lowerC,upperD,lowerE,upperF,lowerG,upperH,lowerI,upperJ,upperK,upperL,upperM,upperN,upperO,upperP,upperQ,upperR]
gracharacters = [glowerA,gupperA,glowerB,gupperB,glowerC,gupperC,glowerD,gupperD,glowerE,gupperE,gColorPacmanO,gColorPacmanCL,gNothing,gFlipPipeNC,gFlipPipeC]
testString = ""
# characters = [upperA]
from components.boxdos.drives.z import ui
pygame.display.set_caption("XWindows Output")
ccx = 0
ccy = 0
winX = 107
winY = 80
def shell_entry(user,version):
    running = True
    while running:
        # All text happens after this code
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
        window.blit(gracharacters[5],(0,0))
        for e in range(winX):
            window.blit(gracharacters[6],(e*6,0))
        window.blit(gracharacters[5],(0,0))
        ui.main(window,characters,gracharacters,winX,winY,user)
        pygame.display.update()