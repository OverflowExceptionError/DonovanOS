import pygame
def renderText(text,x,y,characters,window):
    characterNumber = 0
    for character in text:
        if character == "a":
            window.blit(characters[0],(x + characterNumber,y))
            characterNumber += 6
        elif character == "b":
            window.blit(characters[1],(x + characterNumber,y))
            characterNumber += 6
        elif character == "c":
            window.blit(characters[2],(x + characterNumber,y))
            characterNumber += 6
        elif character == "d":
            window.blit(characters[3],(x + characterNumber,y))
            characterNumber += 6
        elif character == "e":
            window.blit(characters[4],(x + characterNumber,y))
            characterNumber += 6
        elif character == "f":
            window.blit(characters[5],(x + characterNumber,y))
            characterNumber += 6
        elif character == "g":
            window.blit(characters[6],(x + characterNumber,y))
            characterNumber += 6
        elif character == "h":
            window.blit(characters[7],(x + characterNumber,y))
            characterNumber += 6
        elif character == "i":
            window.blit(characters[8],(x + characterNumber,y))
            characterNumber += 6
        elif character == "j":
            window.blit(characters[9],(x + characterNumber,y))
            characterNumber += 6
        elif character == "k":
            window.blit(characters[10],(x + characterNumber,y))
            characterNumber += 6
        elif character == "l":
            window.blit(characters[11],(x + characterNumber,y))
            characterNumber += 6
        elif character == "m":
            window.blit(characters[12],(x + characterNumber,y))
            characterNumber += 6
        elif character == "n":
            window.blit(characters[13],(x + characterNumber,y))
            characterNumber += 6
        elif character == "o":
            window.blit(characters[14],(x + characterNumber,y))
            characterNumber += 6
        elif character == "p":
            window.blit(characters[15],(x + characterNumber,y))
            characterNumber += 6
        elif character == "q":
            window.blit(characters[16],(x + characterNumber,y))
            characterNumber += 6
        elif character == "r":
            window.blit(characters[17],(x + characterNumber,y))
            characterNumber += 6
        elif character == " ":
            characterNumber += 6
        else:
            characterNumber += 6
    characterNumber = 0
def handleCursor(gracharacters,window):
    cursor = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    pygame.mouse.set_visible(False)
    window.blit(gracharacters[0],cursor)
    window.blit(gracharacters[2],(cursor[0]+6,cursor[1]))
    window.blit(gracharacters[3],(cursor[0],cursor[1]+9))
    window.blit(gracharacters[4],(cursor[0]+6,cursor[1]+9))
    return [cursor,list(click)]
def fillScreenGraphicsColor(winX,winY,gracharacters,window,character):
    if True:
        for x in range(winX):
            for y in range(winY):
                window.blit(gracharacters[character],(x*6,y*6))
def cursorIf(sx,sy,ex,ey):
    cursor = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    cursorMain = [cursor,list(click)]
    buttons = cursorMain[1]
    cursor = cursorMain[0]
    if buttons[0]:
        if cursor[0] < ex + 1 and cursor[0] > sx - 1 and cursor[1] < ey + 1 and cursor[1] > sy - 1:
            return True
        else:
            return False
def createDialogBox(winX,winY,gracharacters,characters,window,text,cursorMain,ch=0):
    startX = globals[3]
    startY = globals[4]
    if True:
        for x in range(winX):
            for y in range(winY):
                window.blit(gracharacters[ch],((x*6)+startX,(y*6)+startY))
    for e in range(winX):
        window.blit(gracharacters[6],((e*6) + startX,startY))
    window.blit(gracharacters[5],(startX,startY))
    renderText(text,startX + (winX*6)/2,startY,characters,window)
    cursor = cursorMain[0]
    if cursorMain[1][0]:
        if cursor[0] < startX + (winX*6) and cursor[0] > startX and cursor[1] < startY + 9 and cursor[1] > startY:
            globals[2] = True
    else:
        globals[2] = False
    if globals[2]:
        globals[3] = cursorMain[0][0] - 7
        globals[4] = cursorMain[0][1]
    print("ui.py OutputToDebugLists(list,list): ", end="")
    print(cursorMain)
def DLGBX_BUTTON_OBJECT(winX,sx,sy,ex,ey,gracharacters,characters,text,bg,window):
    if True:
        for x in range(ex):
            for y in range(ey):
                window.blit(gracharacters[bg],((x*6)+sx,(y*6)+sy))
    renderText(text,sx + (winX*6)/2,sy,characters,window)
globals = [False,False,False,30*6,30*6]
def main(window,characters,gracharacters,winX,winY,user):
    fillScreenGraphicsColor(winX,winY,gracharacters,window,12)
    if globals[0]:
        fillScreenGraphicsColor(20,30,gracharacters,window,6)
        renderText("abcdef",0,9,characters,window)
        renderText("ghijklm",0,18,characters,window)
        renderText("the quick brown fox jumped over the lazy dog",0,27,characters,window)
        renderText("option four",0,36,characters,window)
        renderText("execute",0,45,characters,window)
    for e in range(winX):
        window.blit(gracharacters[6],(e*6,0))
    window.blit(gracharacters[5],(0,0))
    renderText("user " + user,6,0,characters,window)
    cursorMain = handleCursor(gracharacters,window)
    if globals[1]:
        createDialogBox(20,10,gracharacters,characters,window,"id",cursorMain,0)
        DLGBX_BUTTON_OBJECT(winX,globals[3] + 20,globals[4] + 10,10,3,gracharacters,characters,"innertext",12,window)
    cursorMain = handleCursor(gracharacters,window)
    buttons = cursorMain[1]
    cursor = cursorMain[0]
    if buttons[0]:
        if cursor[0] < 7 and cursor[0] > -1 and cursor[1] < 10 and cursor[1] > -1:
            if globals[0]:
                globals[0] = False
            else:
                globals[0] = True
        if cursor[0] < 37 and cursor[0] > -1 and cursor[1] < 55 and cursor[1] > 44:
            if globals[0]:
                globals[1] = True
    # print("ui.pu OutputToDebugLists(list,list): ", end="")
    # print(cursor, end="")
    # print(buttons)