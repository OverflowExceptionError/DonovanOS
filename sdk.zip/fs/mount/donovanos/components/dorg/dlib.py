import pygame
def Window(width=640,height=480,title="XWindows Output",icon="A"):
    pygame.font.init()
    try:
        ico = pygame.image.load(icon)
    except:
        ico = None
    window = pygame.display.set_mode((width,height))
    pygame.display.set_caption(title)
    try:
        pygame.display.set_icon(ico)
    except:
        pass
    return window
def Image(path):
    return pygame.image.load(path)
def Cursor():
    cursor = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    pygame.mouse.set_visible(False)
    return [cursor, click]
def CursorUpdate(image_cur,window_obj):
    window_obj.blit(image_cur,Cursor()[0])
    return Cursor()
def WindowUpdate(window_obj,color=(155,155,155)):
    window_obj.fill(color)
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            return True
    return False
def WindowPostRun():
    pygame.display.update()
def GetPygame():
    return pygame
def Text(text='DOrg Render Test',size=15,font=None,color=(0,0,0),anti_alias=False):
    font = pygame.font.Font(font, size)
    return font.render(text,anti_alias, color)