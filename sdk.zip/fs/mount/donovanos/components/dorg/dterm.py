from components.dorg import dlib
import pygame
win = dlib.Window()
terminal_text = []
import os,_thread
def start_new_process(process_name='dpm.py',useless=False):
    os.system('py ' + process_name)
def dprint(text,window=win):
    terminal_text.append(dlib.Text(text))
def shell_entry(user,version):
    print('DOS NASH Enviroment (ported to a GUI!)')
    print('(c) 2022 The DonovanOS Team, DOrg Development')
    print('Shell version 1.0')
    print('DonovanOS version ' + version)
    if user == 'login':
        print('Invalid permissions to start DonovanOS NASH Enviroment.')
        print('More detailed information')
        print('VERSION ' + version)
        print('USER *Now this is the fault! - here\'s why! /docs/dterm_crash_user.txt* ' + user)
        exit()
    running = True
    directory = '/'
    params = ''
    tick = 0
    ttick = 0
    caps = False
    while running:
        if dlib.WindowUpdate(win):
            running = False
        tick += 1
        cmd = ''
        caps = False
        for e in terminal_text:
            win.blit(terminal_text[ttick],(0,ttick*15))
            ttick += 1
        ttick = 0
        keys = pygame.key.get_pressed()
        if keys[pygame.K_a] and tick > 50:
            if not caps:
                cmd += 'a'
            else:
                cmd += 'A'
            tick = 0
        if keys[pygame.K_b] and tick > 50:
            if not caps:
                cmd += 'b'
            else:
                cmd += 'B'
            tick = 0
        if keys[pygame.K_c] and tick > 50:
            if not caps:
                cmd += 'c'
            else:
                cmd += 'C'
            tick = 0
        if keys[pygame.K_d] and tick > 50:
            if not caps:
                cmd += 'd'
            else:
                cmd += 'D'
            tick = 0
        if keys[pygame.K_SPACE] and tick > 50:
            cmd += ' '
            tick = 0
        if keys[pygame.K_RETURN] and tick > 50:
            print(cmd)
            cmd = cmd.split(' ')
            if cmd[0] == 'aa' or cmd[0] == 'aaaa' or cmd[0] == 'baaa':
                running = False
            elif cmd[0] == 'aba':
                params = ''
                for e in cmd:
                    if e != cmd[0]:
                        params += e + ' '
                start_new_process('dpm.py ' + params)
            elif cmd[0] == 'aaa':
                dprint('Command statement previously had these arguments: ' + params)
            elif cmd[0] == 'bba':
                dprint('System specifications for DonovanOS')
                dprint('DonovanOS running on (UNKOWN OPERATING SYSTEM) with DTerm Graphical User Enviroment')
                dprint('Most likely Python 3')
            elif cmd[0] == 'baa':
                params = ''
                for e in cmd:
                    if e != cmd[0]:
                        params += e + ' '
                _thread.start_new_thread(start_new_process,(params,True))
            elif cmd[0] == 'b':
                if len(cmd) < 2:
                    print('Not enough paramaters!')
                else:
                    try:
                        os.chdir(cmd[1])
                    except:
                        dprint('Directory invalid or not found.')
                    else:
                        directory += cmd[1] + '/'
            elif cmd[0] == 'a':
                try:
                    if directory == '/' or cmd[1].split('/')[0] == '':
                        if user == 'root':
                            os.mkdir(cmd[1])
                except:
                    dprint('Failed to make directory - do you have the right permissions?')
            elif cmd[0] == 'c':
                try:
                    os.remove(cmd[1])
                except:
                    print('This might be an operating system based error.')
            elif cmd[0] == 'ddac':
                try:
                    os.rmdir(cmd[1])
                except:
                    dprint('Unknown error occurred')
            elif cmd[0] == 'cc':
                dprint('No, YOUR the chicken. BCAWK BCAWK!')
            elif cmd[0] == '' or cmd[0] == 'ignore':
                pass
            else:
                dprint('Command not found.')
            tick = 0
            cmd = ''
        dlib.CursorUpdate(dlib.Image('/pkg/dorg/cursor.png'),win)
        dlib.WindowPostRun()