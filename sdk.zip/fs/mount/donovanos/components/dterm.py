import os,_thread
def start_new_process(process_name='dpm.py',useless=False):
    os.system('py ' + process_name)
def shell_entry(user,version):
    print('DOS NASH Enviroment')
    print('(c) 2022 The DonovanOS Team')
    print('Shell version 1.1')
    print('See /docs/dterm_1.1_changelog.txt')
    print('DonovanOS version ' + version)
    if user == 'login':
        print('Invalid permissions to start DonovanOS NASH Enviroment.')
        print('More detailed information')
        print('VERSION ' + version)
        print('USER *Now this is the fault! - here\'s why! /docs/dterm_crash_user.txt* ' + user)
        exit()
    running = True
    directory = '/'
    params = ''
    users = open('/pkg/dterm/users.txt').read()
    users = users.split('\n')
    dirs = open('/pkg/dterm/directories.txt').read()
    dirs = dirs.split('\n')
    usrdir = ''
    matched = False
    for e in users:
        if e == user:
            matched = True
    if matched:
        for e in dirs:
            if e == '/pkg/dterm/' + user:
                usrdir = e
    if not matched:
        print('DOS NASH User Setup')
        print('Alright, you aren\'t cached, so we\'ll assume you dont have an account.')
        print('Working on setting up new user...')
        f = open('/pkg/dterm/users.txt','a')
        f.write(user + '\n')
        f.close()
        f = open('/pkg/dterm/directories.txt','a')
        f.write('/pkg/dterm/' + user + '\n')
        f.close()
        os.mkdir('/pkg/dterm/' + user)
        a = input('Do you want to start in your user directory? (Y/N) ')
        if a == 'Y' or a == 'yes':
            os.chdir('/pkg/dterm/' + user)
            directory = '/pkg/dterm/' + user
        else:
            pass
        print('Welcome to your new desktop enviroment!')
        usrdir = '/pkg/dterm/' + user
    while running:
        cmd = input(user + ' ' + directory + ' $ ')
        cmd = cmd.split(' ')
        if cmd[0] == 'exit' or cmd[0] == 'quit' or cmd[0] == 'logout':
            running = False
        elif cmd[0] == 'dpm':
            params = ''
            for e in cmd:
                if e != cmd[0]:
                    params += e + ' '
            params += user
            start_new_process('/pkg/dpm/dpm.py ' + params)
        elif cmd[0] == 'list_recent_command':
            print('Command statement previously had these arguments: ' + params)
        elif cmd[0] == 'sysdetails':
            print('System specifications for DonovanOS')
            print('DonovanOS running on (UNKOWN OPERATING SYSTEM) with DTerm User Enviroment')
            print('Most likely Python 3')
        elif cmd[0] == 'runprog':
            params = '/pkg/' + cmd[1] + '/' + cmd[1] + '.py'
            for e in cmd:
                if e != cmd[0] and e != cmd[1]:
                    params += e + ' '
            _thread.start_new_thread(start_new_process,(params,True))
        elif cmd[0] == 'firstboot':
            if matched:
                print('No, this is not your first time using DonovanOS DTerm.')
            else:
                print('Yes, welcome new user!')
        elif cmd[0] == 'cd' or cmd[0] == 'chdir':
            if len(cmd) < 2:
                print('Not enough paramaters!')
            else:
                try:
                    if cmd[1] != '~':
                        os.chdir(cmd[1])
                    else:
                        os.chdir(usrdir)
                except:
                    print('Directory invalid or not found.')
                else:
                    if cmd[1] != '~':
                        directory += cmd[1] + '/'
                    else:
                        directory = usrdir + '/'
        elif cmd[0] == 'md' or cmd[0] == 'mkdir':
            try:
                if directory == '/' or cmd[1].split('/')[0] == '':
                    if user == 'root':
                        os.mkdir(cmd[1])
            except:
                print('Failed to make directory - do you have the right permissions?')
        elif cmd[0] == 'rm':
            try:
                os.remove(cmd[1])
            except:
                print('This might be an operating system based error.')
        elif cmd[0] == 'rd' or cmd[0] == 'rmdir':
            try:
                os.rmdir(cmd[1])
            except:
                print('Unknown error occurred')
        elif cmd[0] == 'chicken' or cmd[0] == 'Chicken!':
            print('No, YOUR the chicken. BCAWK BCAWK!')
            print('DonovanOS Message:')
            print('Shell was terminated by user.')
            print('Shell: DTerm')
            print('Path: /components/dterm.py')
            running = False
        elif cmd[0] == 'ls':
            for e in os.listdir():
                print(e)
        elif cmd[0] == 'whatareyou?':
            print('I am a DonovanOS Shell designed to have basic features and the ability to launch other DPM-based packages and shells.')
        else:
            params = '/pkg/' + cmd[0] + '/' + cmd[0] + '.py'
            for e in cmd:
                if e != cmd[0]:
                    params += e + ' '
            _thread.start_new_thread(start_new_process,(params,True))