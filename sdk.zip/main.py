print('Booting DonovanOS...')
print('DonovanOS Kernel version 1.0')
print('(C) 2022 Donovan Baker')
print('Looking for data...')
print('/fs/bootldr')
import os
try:
	bop = open('fs/bootcfg.txt','r').read()
except:
	bop = 'DonovanOS,/donovanos,boot.py'
bop = bop.split('\n')
print('Options:')
num = 1
for e in bop:
	print(str(num) + '. ' + e.split(',')[0])
	num += 1
num = 0
a = input('Choose > ')
for e in range(-1,len(bop)):
	if a == str(e + 1):
		print('Found choice')
		print('Now booting ' + bop[e].split(',')[0] + ' from ' + bop[e].split(',')[1] + '/' + bop[e].split(',')[2])
		os.chdir('fs' + bop[e].split(',')[1])
		os.system('py ' + bop[e].split(',')[2])
		exit()